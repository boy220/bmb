# iReverse-UniSPD-FRP-Tools-Non-Console-x86-CSharp
For educational purposes about Unisoc Spreadtrum Download Mode In CSharp

Based : 
- https://github.com/ilyakurdyukov/spreadtrum_flash
- https://github.com/fxsheep/sharkalaka
  
[![image-2024-02-05-120326859.png](https://i.ibb.co/FHNrB5G/image-2024-02-05-120326859.png)](https://ibb.co/Bndpgy8)

